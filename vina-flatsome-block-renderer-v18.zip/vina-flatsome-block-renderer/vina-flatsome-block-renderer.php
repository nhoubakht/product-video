<?php
/**
 * Plugin Name: Vina Flatsome Block Renderer
 * Description: Restores old Flatsome UX Block content on WooCommerce products, including section, row, col, ux_image and ux_banner, with WooCommerce-safe rendering with non-destructive legacy shortcode normalization, duplicate video-banner protection by MP4 URL, and safe WooCommerce rendering.
 * Version: 17.0.0
 * Author: Vina
 */
if (!defined('ABSPATH')) exit;

function vina_find_old_block($id) {
    $id=trim(str_replace(array('“','”','‘','’'),array('"','"',"'", "'"),(string)$id));
    if ($id==='') return false;
    if (ctype_digit($id)) { $p=get_post((int)$id); if($p) return $p; }
    foreach(array('blocks','uxblock','ux_block') as $type){
        $p=get_page_by_path(sanitize_title($id),OBJECT,$type); if($p) return $p;
        $posts=get_posts(array('post_type'=>$type,'post_status'=>array('publish','private','draft'),'posts_per_page'=>1,'title'=>$id,'suppress_filters'=>false));
        if(!empty($posts)) return $posts[0];
    }

    // Some Flatsome installations store UX blocks under a custom post type
    // with a different slug. As a final non-destructive lookup, search all
    // public/private/draft posts by exact title.
    $posts=get_posts(array(
        'post_type'=>'any',
        'post_status'=>array('publish','private','draft'),
        'posts_per_page'=>20,
        's'=> '',
        'title'=>$id,
        'suppress_filters'=>false,
    ));
    foreach($posts as $p){
        if($p->post_type!=='product' && $p->post_type!=='attachment') return $p;
    }
    return false;
}
function vina_attr($atts,$key,$default=''){ return isset($atts[$key])?trim((string)$atts[$key]):$default; }

function vina_ux_image_shortcode($atts=array(),$content=''){
    $id=vina_attr($atts,'id');
    if($id===''||!ctype_digit($id)) return '';
    $url=wp_get_attachment_image_url((int)$id,'full'); if(!$url) return '';
    $alt=get_post_meta((int)$id,'_wp_attachment_image_alt',true); if($alt==='') $alt=get_the_title((int)$id);
    return '<div class="vina-ux-image"><img src="'.esc_url($url).'" alt="'.esc_attr($alt).'" loading="lazy"></div>';
}
function vina_resolve_legacy_video_url(){
    $candidates=array();
    $post_id=get_the_ID();
    if($post_id){
        $keys=array('video','video_url','video_mp4','product_video','product_video_url','_video','_video_url','_video_mp4','_product_video','_product_video_url');
        foreach($keys as $key){
            $v=get_post_meta($post_id,$key,true);
            if(is_string($v) && $v!=='') $candidates[]=$v;
        }
        $all=get_post_meta($post_id);
        foreach($all as $vals){
            foreach((array)$vals as $v){ if(is_string($v) && $v!=='') $candidates[]=$v; }
        }
        $attachments=get_attached_media('video',$post_id);
        foreach($attachments as $a){
            $u=wp_get_attachment_url($a->ID); if($u) $candidates[]=$u;
        }
    }
    foreach($candidates as $v){
        $v=html_entity_decode(wp_strip_all_tags((string)$v),ENT_QUOTES,'UTF-8');
        if(preg_match('~https?://[^\s\"\'<>\]\)]+\.(?:mp4|webm|ogg)(?:\?[^\s\"<>]*)?~i',$v,$m)) return esc_url_raw($m[0]);
    }
    return '';
}

function vina_normalize_legacy_video_placeholders($content){
    if(!is_string($content) || $content==='') return $content;
    $source=vina_resolve_legacy_video_url();
    $seen=false;
    // Handle both literal `video` lines and empty [video] shortcodes. Keep the
    // first one only, and give it a real source when the product/block stores one.
    $content=preg_replace_callback('/(^|[\r\n])\s*(?:\*\*)?video(?:\*\*)?\s*(?=[\r\n]|$)/i',function($m) use (&$seen,$source){
        if($seen) return $m[1];
        $seen=true;
        return $m[1].($source ? '[video src="'.esc_attr($source).'"]' : '');
    },$content);
    $content=preg_replace_callback('/\[video\b([^\]]*)\]/i',function($m) use (&$seen,$source){
        if($seen) return '';
        $seen=true;
        $attrs=$m[1];
        if(!preg_match('/\bsrc\s*=\s*["\']([^"\']+)["\']/i',$attrs) && $source){
            return '[video src="'.esc_attr($source).'"]';
        }
        return '[video'.$attrs.']';
    },$content);
    return $content;
}

function vina_ux_html_shortcode($atts=array(),$content=''){
    // ux_html is intentionally a transparent wrapper: Flatsome stores raw HTML/video
    // markup inside this shortcode. Normalize only the legacy video placeholder;
    // do not escape or rewrite the rest of the HTML.
    $content=vina_normalize_legacy_video_placeholders($content);
    return '<div class="vina-ux-html">'.do_shortcode($content).'</div>';
}
function vina_ux_text_shortcode($atts=array(),$content=''){
    $atts=shortcode_atts(array('class'=>'','style'=>'','text_align'=>'','width'=>'','color'=>'','size'=>'','margin'=>'','padding'=>'','animate'=>''),$atts,'ux_text');
    $classes='vina-ux-text';
    if($atts['class']!=='') $classes.=' '.sanitize_html_class($atts['class']);
    $style='';
    foreach(array('style','width','color','size','margin','padding') as $k){ if($atts[$k]!=='') $style.=' '.esc_attr($atts[$k]); }
    if($atts['text_align']!=='') $style.=' text-align:'.esc_attr($atts['text_align']).';';
    return '<div class="'.esc_attr($classes).'"'.($style!==''?' style="'.trim($style).'"':'').'>'.do_shortcode($content).'</div>';
}
function vina_gap_shortcode($atts=array(),$content=''){
    $atts=shortcode_atts(array('height'=>'30px','height__sm'=>'20px'),$atts,'gap');
    return '<div class="vina-gap" style="height:'.esc_attr($atts['height']).';"></div>';
}

function vina_col_shortcode($atts=array(),$content=''){
    $span=preg_replace('/[^0-9]/','',vina_attr($atts,'span','12')); $sm=preg_replace('/[^0-9]/','',vina_attr($atts,'span__sm','12'));
    if($span==='')$span='12'; if($sm==='')$sm='12';
    return '<div class="vina-col vina-col-'.$span.' vina-col-sm-'.$sm.'">'.do_shortcode($content).'</div>';
}
function vina_row_shortcode($atts=array(),$content=''){ return '<div class="vina-row">'.do_shortcode($content).'</div>'; }
function vina_section_shortcode($atts=array(),$content=''){ return '<section class="vina-section"><div class="vina-section-inner">'.do_shortcode($content).'</div></section>'; }

function vina_ux_banner_shortcode($atts=array(),$content=''){
    $height=vina_attr($atts,'height','500px');
    $height_sm=vina_attr($atts,'height__sm','');
    $video=vina_attr($atts,'video_mp4','');
    if(preg_match('~https?://[^\s\]\)"\'*]+\.mp4~i',$video,$m)) $video=$m[0];
    $style='--vina-banner-height:'.esc_attr($height).';';
    if($height_sm!=='') $style.='--vina-banner-height-sm:'.esc_attr($height_sm).';';
    $html='<div class="vina-ux-banner" style="'.esc_attr($style).'">';
    if($video!=='') $html.='<video class="vina-ux-banner-video" autoplay muted loop playsinline preload="metadata"><source src="'.esc_url($video).'" type="video/mp4"></video>';
    $inner=do_shortcode($content);
    if(trim($inner)!=='') $html.='<div class="vina-ux-banner-content">'.$inner.'</div>';
    return $html.'</div>';
}
add_shortcode('ux_image','vina_ux_image_shortcode');
if(!shortcode_exists('ux_text')) add_shortcode('ux_text','vina_ux_text_shortcode');
if(!shortcode_exists('ux_html')) add_shortcode('ux_html','vina_ux_html_shortcode');
if(!shortcode_exists('gap')) add_shortcode('gap','vina_gap_shortcode');
add_shortcode('col','vina_col_shortcode');
add_shortcode('row','vina_row_shortcode');
add_shortcode('section','vina_section_shortcode');
add_shortcode('ux_banner','vina_ux_banner_shortcode');

// Safe fallback for Flatsome product-grid shortcode. If Flatsome already
// provides ux_products, its native renderer is preserved.
function vina_ux_products_shortcode($atts=array(),$content=''){
    $atts=shortcode_atts(array('type'=>'row','cat'=>'','products'=>'12','orderby'=>'menu_order','order'=>'DESC','tags'=>''),$atts,'ux_products');
    $limit=max(1,min(100,(int)$atts['products']));
    $args=array('post_type'=>'product','post_status'=>'publish','posts_per_page'=>$limit,'orderby'=>sanitize_key($atts['orderby']),'order'=>($atts['order']==='ASC'?'ASC':'DESC'));
    $tax=array();
    if($atts['cat']!=='') $tax[]=array('taxonomy'=>'product_cat','field'=>'term_id','terms'=>array_map('intval',preg_split('/\s*,\s*/',$atts['cat'])));
    if($atts['tags']!=='') $tax[]=array('taxonomy'=>'product_tag','field'=>'term_id','terms'=>array_map('intval',preg_split('/\s*,\s*/',$atts['tags'])));
    if($tax) $args['tax_query']=array_merge(array('relation'=>'AND'),$tax);
    $q=new WP_Query($args); if(!$q->have_posts()) return '';
    ob_start(); echo '<div class="products row columns-4">';
    while($q->have_posts()){ $q->the_post(); wc_get_template_part('content','product'); }
    echo '</div>'; wp_reset_postdata(); return ob_get_clean();
}
if(!shortcode_exists('ux_products')) add_shortcode('ux_products','vina_ux_products_shortcode');



/**
 * Normalize legacy Flatsome shortcode content saved by visual/Markdown editors.
 * This intentionally touches only wrappers around the supported shortcodes and
 * Markdown formatting; normal Persian/HTML text is left intact.
 */
function vina_normalize_legacy_flatsome_content($html) {
    if (!is_string($html) || $html === '') return $html;

    $html = str_replace(
        array('“','”','‘','’','&#8220;','&#8221;','&#8216;','&#8217;'),
        array('"','"',"'","'",'"','"',"'","'"),
        $html
    );

    // A legacy editor can save the opening ux_html token without its leading '['
    // (e.g. **ux_html]**). Recover only this exact malformed wrapper.
    $html = preg_replace('/(?:\*\*|__)\s*ux_html\]\s*(?:\*\*|__)/i', '[ux_html]', $html);
    $html = preg_replace('/(?:^|[\r\n])\s*ux_html\]\s*(?=[\r\n]|$)/i', '$1[ux_html]', $html);

    // Remove Markdown bold/italic markers around complete Flatsome shortcode tags.
    $html = preg_replace(
        '/(?:\\*\\*|__|\\*|_)\\s*(\\[\\/?(?:section|row|col|ux_image|ux_banner|ux_html|ux_products|ux_text|gap)\\b[^\\]]*\\])\\s*(?:\\*\\*|__|\\*|_)/i',
        '$1',
        $html
    );

    // Remove paragraph/br wrappers introduced by TinyMCE/Markdown conversion.
    $html = preg_replace(
        '/<p[^>]*>\\s*(\\[\\/?(?:section|row|col|ux_image|ux_banner|ux_html|ux_products|ux_text|gap)\\b[^\\]]*\\])\\s*<\\/p>/i',
        '$1',
        $html
    );
    $html = preg_replace(
        '/<br\\s*\\/?>\\s*(\\[\\/?(?:section|row|col|ux_image|ux_banner|ux_html|ux_products|ux_text|gap)\\b[^\\]]*\\])/i',
        '$1',
        $html
    );
    $html = preg_replace(
        '/(\\[\\/?(?:section|row|col|ux_image|ux_banner|ux_html|ux_products|ux_text|gap)\\b[^\\]]*\\])\\s*<br\\s*\\/?>/i',
        '$1',
        $html
    );

    // Unwrap Markdown links that contain a URL used as a video_mp4 value.
    $html = preg_replace_callback(
        '~\\*\\*\\[\\*\\*(https?://[^\\]\\s]+)\\*\\*\\]\\(https?://[^\\)]+\\)\\*\\*~i',
        function($m){ return $m[1]; },
        $html
    );

    // Also recover video_mp4 if the editor stored Markdown/HTML entities in it.
    $html = preg_replace_callback(
        '/video_mp4\\s*=\\s*"([^"]*)"/i',
        function($m){
            $value = html_entity_decode($m[1], ENT_QUOTES, 'UTF-8');
            if (preg_match("~https?://[^\\s\\]\\)\"']+\\.mp4~i", $value, $u)) {
                return 'video_mp4="'.$u[0].'"';
            }
            return 'video_mp4="'.esc_attr($value).'"';
        },
        $html
    );

    // `video` placeholders are normalized inside ux_html, where we can resolve
    // the product's actual video URL and keep only the first player. Do not turn
    // bare text into an empty WordPress [video] shortcode here.


    return $html;
}

function vina_block_shortcode($atts=array(),$content=''){
    $atts=shortcode_atts(array('id'=>''),$atts,'block');
    $id=vina_attr($atts,'id');

    $post=vina_find_old_block($id);
    if(!$post){
        // Never silently delete a product/page's content when an old block ID
        // cannot be resolved. Administrators get a diagnostic; visitors keep
        // the original shortcode instead of an empty page.
        return current_user_can('manage_options')
            ? '<div style="padding:10px;border:1px dashed #c00;color:#900;">Block <strong>'.esc_html($id).'</strong> پیدا نشد.</div>'
            : '[block id="'.esc_attr($id).'"]';
    }

    /*
     * IMPORTANT:
     * Do NOT keep a global/request-level "already rendered" flag here.
     * Flatsome/WooCommerce/WoodMart can render the same block through more
     * than one content path, and a global flag can make a second product/page
     * lose its entire block. We only guard true recursive rendering.
     */
    static $rendering=array();
    $block_key=(string)$post->ID;
    if(isset($rendering[$block_key])){
        return '';
    }
    $rendering[$block_key]=true;

    $html=str_replace(
        array('“','”','‘','’'),
        array('"','"',"'","'"),
        $post->post_content
    );

    /*
     * Normalize editor-generated Markdown/HTML around legacy Flatsome shortcodes.
     * Some editors save shortcode tags as **[section]**, **[ux_image ...]**,
     * or put <p>/<br> around them. WordPress may then fail to recognize the
     * structural shortcode, which makes the whole old block appear to vanish.
     */
    $html = vina_normalize_legacy_flatsome_content($html);

    /*
     * Legacy product content can arrive from an editor as Markdown, e.g.
     * **[**https://site/video.mp4**](https://site/video.mp4)**
     * inside a shortcode attribute. WordPress's shortcode parser treats the
     * inner square brackets as shortcode syntax, so normalize this BEFORE
     * do_shortcode().
     */
    $html = preg_replace_callback(
        '~\*\*\[\*\*(https?://[^\]\s]+)\*\*\]\(https?://[^\)]+\)\*\*~i',
        function($m){ return $m[1]; },
        $html
    );

    // Also remove Markdown bold markers surrounding shortcode tags.
    $html = preg_replace('/\*\*(\[\/?(?:ux_banner|ux_image|section|row|col)\b[^\]]*\])\*\*/i', '$1', $html);

    // Recover the real MP4 URL if an editor stored it as Markdown.
    $html=preg_replace_callback(
        '/video_mp4\s*=\s*"([^"]*)"/i',
        function($m){
            $value = html_entity_decode($m[1], ENT_QUOTES, 'UTF-8');
            if(preg_match('~https?://[^\s\]\)"\']+\.mp4~i',$value,$u)){
                return 'video_mp4="'.$u[0].'"';
            }
            return $m[0];
        },
        $html
    );

    // If the old editor saved two identical video banners, keep only the first.
    $html = vina_remove_duplicate_ux_banners($html);

    // Run the shortcode parser after normalization. Never suppress the block
    // merely because it was rendered earlier in this request.
    $html=do_shortcode($html);
    $html=shortcode_unautop($html);

    // A legacy ux_html can still yield more than one native video element.
    // Keep the first playable video and remove only later duplicate/empty players.
    // editor/shortcode pipeline. Remove only truly identical HTML5 video
    // sources; images, text, gaps, sections and different videos are kept.
    $html = vina_remove_duplicate_html5_videos($html);
    $html = vina_remove_duplicate_media_embeds($html);

    unset($rendering[$block_key]);

    return '<div class="vina-flatsome-block" data-block="'.esc_attr($post->ID).'">'.$html.'</div>';
}

add_shortcode('block','vina_block_shortcode');


/*
 * WooCommerce's standard Description tab uses the_content().
 * WoodMart's accordion is a presentation layer around that output, so
 * process the shortcode exactly once here.
 */
function vina_render_flatsome_blocks_in_product_content($content) {
    if (is_admin() || !is_singular('product') || !is_string($content) || $content === '') {
        return $content;
    }

    /*
     * WordPress already runs do_shortcode() on the_content. Running it again
     * here can cause custom block renderers to execute twice and is one of the
     * main ways an otherwise valid block gets emptied. This filter therefore
     * ONLY normalizes legacy Markdown/HTML wrappers before the normal shortcode
     * pass; it never calls do_shortcode() itself.
     */
    if (has_shortcode($content, 'block') ||
        preg_match('/\[\/?(?:section|row|col|ux_image|ux_banner|ux_html|ux_products|ux_text|gap)\b/i', $content)) {
        $content = vina_normalize_legacy_flatsome_content($content);
    }

    return $content;
}
add_filter('the_content', 'vina_render_flatsome_blocks_in_product_content', 20);

/*
 * If the old block itself contains two identical ux_banner shortcodes
 * pointing to the same MP4, keep the first one. Different banners are
 * preserved.
 */
function vina_remove_duplicate_ux_banners($html) {
    if (!is_string($html) || $html === '') return $html;

    $seen = array();

    return preg_replace_callback(
        '/\[ux_banner\b([^\]]*)\][\s\S]*?\[\/ux_banner\]/i',
        function($m) use (&$seen) {
            $attrs = $m[1];

            if (!preg_match('/video_mp4\s*=\s*"([^"]*)"/i', $attrs, $vm)) {
                return $m[0];
            }

            $video = vina_normalize_video_url($vm[1]);
            if ($video === '') return $m[0];

            // Deduplicate by the MP4 URL only. The same video may appear twice
            // with different desktop/mobile height attributes; keep the first.
            $key = md5($video);

            if (isset($seen[$key])) {
                return '';
            }

            $seen[$key] = true;
            return $m[0];
        },
        $html
    );
}


function vina_remove_duplicate_html5_videos($html) {
    if (!is_string($html) || $html === '') return $html;
    $seen = array();

    return preg_replace_callback(
        '~<video\b([^>]*)>([\s\S]*?)</video>~i',
        function($m) use (&$seen) {
            $tag = $m[0];
            $body = $m[2];
            $src = '';

            if (preg_match('~<source\b[^>]*\bsrc\s*=\s*["\']([^"\']+)["\']~i', $body, $sm)) {
                $src = html_entity_decode($sm[1], ENT_QUOTES, 'UTF-8');
            } elseif (preg_match('~\bsrc\s*=\s*["\']([^"\']+)["\']~i', $m[1], $vm)) {
                $src = html_entity_decode($vm[1], ENT_QUOTES, 'UTF-8');
            }

            $src = trim($src);
            if ($src === '') return $tag;

            // Normalize only the URL for comparison; do not modify the actual
            // video markup that is sent to the browser.
            $key = md5(esc_url_raw($src));
            if (isset($seen[$key])) return '';
            $seen[$key] = true;
            return $tag;
        },
        $html
    );
}

function vina_remove_duplicate_media_embeds($html) {
    if (!is_string($html) || $html === '') return $html;
    $seen=array();
    return preg_replace_callback('~<(iframe|embed)\b([^>]*)>[\s\S]*?</\1>|<video\b([^>]*)>[\s\S]*?</video>~i', function($m) use (&$seen){
        $tag=$m[0]; $src='';
        if(preg_match('~\bsrc\s*=\s*[\"\']([^\"\']+)~i',$tag,$sm)) $src=html_entity_decode($sm[1],ENT_QUOTES,'UTF-8');
        if($src==='') return $tag;
        $key=md5(strtolower(trim($src)));
        if(isset($seen[$key])) return '';
        $seen[$key]=true; return $tag;
    },$html);
}

function vina_normalize_video_url($value) {
    $value = html_entity_decode((string)$value, ENT_QUOTES, 'UTF-8');
    if (preg_match('~https?://[^\s\]\)"\'*]+\.mp4~i', $value, $m)) {
        return esc_url_raw($m[0]);
    }
    return trim($value, " \t\n\r\0\x0B*[]()\"'");
}

function vina_flatsome_renderer_css(){
    if(!is_product()) return;
?>
<style id="vina-flatsome-renderer">
.vina-flatsome-block{width:100%;box-sizing:border-box}.vina-flatsome-block .vina-ux-html{width:100%;box-sizing:border-box}.vina-flatsome-block .vina-ux-html video{max-width:100%;height:auto}
.vina-flatsome-block .vina-section{width:100%;margin:0 0 30px;padding:0}
.vina-flatsome-block .vina-section-inner{width:100%;max-width:100%;margin:0 auto}
.vina-flatsome-block .vina-row{display:flex;flex-wrap:wrap;width:100%;margin:0 -10px}
.vina-flatsome-block .vina-col{box-sizing:border-box;padding:10px}
.vina-flatsome-block .vina-col-1{width:8.333333%}.vina-flatsome-block .vina-col-2{width:16.666667%}.vina-flatsome-block .vina-col-3{width:25%}.vina-flatsome-block .vina-col-4{width:33.333333%}.vina-flatsome-block .vina-col-5{width:41.666667%}.vina-flatsome-block .vina-col-6{width:50%}.vina-flatsome-block .vina-col-7{width:58.333333%}.vina-flatsome-block .vina-col-8{width:66.666667%}.vina-flatsome-block .vina-col-9{width:75%}.vina-flatsome-block .vina-col-10{width:83.333333%}.vina-flatsome-block .vina-col-11{width:91.666667%}.vina-flatsome-block .vina-col-12{width:100%}
.vina-flatsome-block .vina-ux-image{width:100%;line-height:0}.vina-flatsome-block .vina-ux-image img{display:block;width:100%;height:auto;max-width:100%;margin:0}
.vina-flatsome-block .vina-ux-banner{position:relative;width:100%;height:var(--vina-banner-height,500px);overflow:hidden;background:#000;margin:0 0 30px}
.vina-flatsome-block .vina-ux-banner-video{position:absolute;inset:0;width:100%;height:100%;display:block;object-fit:cover;object-position:center}
.vina-flatsome-block .vina-ux-banner-content{position:relative;z-index:2;width:100%;height:100%}
@media(max-width:767px){
.vina-flatsome-block .vina-col-sm-12{width:100%}.vina-flatsome-block .vina-col-sm-11{width:91.666667%}.vina-flatsome-block .vina-col-sm-10{width:83.333333%}.vina-flatsome-block .vina-col-sm-9{width:75%}.vina-flatsome-block .vina-col-sm-8{width:66.666667%}.vina-flatsome-block .vina-col-sm-7{width:58.333333%}.vina-flatsome-block .vina-col-sm-6{width:50%}.vina-flatsome-block .vina-col-sm-5{width:41.666667%}.vina-flatsome-block .vina-col-sm-4{width:33.333333%}.vina-flatsome-block .vina-col-sm-3{width:25%}.vina-flatsome-block .vina-col-sm-2{width:16.666667%}.vina-flatsome-block .vina-col-sm-1{width:8.333333%}
.vina-flatsome-block .vina-row{margin:0}.vina-flatsome-block .vina-ux-banner{height:var(--vina-banner-height-sm,var(--vina-banner-height,500px))}
}
</style>
<?php
}
add_action('wp_head','vina_flatsome_renderer_css',999);
