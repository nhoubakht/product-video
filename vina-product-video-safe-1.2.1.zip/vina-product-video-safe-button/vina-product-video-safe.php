<?php
/**
 * Plugin Name: Vina Product Video Button (Safe)
 * Description: Adds a product video URL field and a button below the WooCommerce product gallery that opens the video in a modal.
 * Version: 1.2.1
 * Author: Vina
 * Requires Plugins: woocommerce
 * Text Domain: vina-product-video
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

final class Vina_Product_Video_Button_Safe {
    const META_KEY = '_vina_product_video_url';
    private static $printed = false;

    public function __construct() {
        add_action( 'add_meta_boxes', array( $this, 'add_meta_box' ) );
        add_action( 'save_post_product', array( $this, 'save_product_video' ) );
        add_action( 'admin_enqueue_scripts', array( $this, 'admin_assets' ) );
        // Standard WooCommerce position: immediately after the product gallery and before the summary.
        add_action( 'woocommerce_before_single_product_summary', array( $this, 'output_button' ), 25 );
        // Fallback for themes that alter the standard gallery hook placement.
        add_action( 'woocommerce_after_single_product_summary', array( $this, 'output_button' ), 1 );
        add_action( 'wp_enqueue_scripts', array( $this, 'frontend_assets' ) );
    }

    public function add_meta_box() {
        add_meta_box(
            'vina_product_video_box',
            'ویدئوی محصول (وینا)',
            array( $this, 'render_meta_box' ),
            'product',
            'side',
            'default'
        );
    }

    public function render_meta_box( $post ) {
        wp_nonce_field( 'vina_product_video_save', 'vina_product_video_nonce' );
        $url = get_post_meta( $post->ID, self::META_KEY, true );
        ?>
        <p><label for="vina_video_safe_url">آدرس فایل ویدئو (ترجیحاً MP4)</label></p>
        <input type="url" id="vina_video_safe_url" name="vina_video_safe_url" value="<?php echo esc_attr( $url ); ?>" style="width:100%" placeholder="https://example.com/video.mp4" />
        <p><button type="button" class="button" id="vina_video_safe_media">انتخاب ویدئو از کتابخانه رسانه</button></p>
        <p class="description">پس از انتخاب ویدئو، محصول را به‌روزرسانی کنید.</p>
        <?php
    }

    public function save_product_video( $post_id ) {
        if ( ! isset( $_POST['vina_product_video_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['vina_product_video_nonce'] ) ), 'vina_product_video_save' ) ) { return; }
        if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) { return; }
        if ( ! current_user_can( 'edit_post', $post_id ) ) { return; }
        if ( isset( $_POST['vina_video_safe_url'] ) ) {
            $url = esc_url_raw( trim( wp_unslash( $_POST['vina_video_safe_url'] ) ) );
            if ( $url ) { update_post_meta( $post_id, self::META_KEY, $url ); }
            else { delete_post_meta( $post_id, self::META_KEY ); }
        }
    }

    public function admin_assets( $hook ) {
        if ( ! in_array( $hook, array( 'post.php', 'post-new.php' ), true ) ) { return; }
        $screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
        if ( ! $screen || 'product' !== $screen->post_type ) { return; }
        wp_enqueue_media();
        $admin_js = <<<'JS'
jQuery(function($){var frame;$('#vina_video_safe_media').on('click',function(e){e.preventDefault();if(frame){frame.open();return;}frame=wp.media({title:'انتخاب ویدئوی محصول',button:{text:'استفاده از این ویدئو'},library:{type:'video'},multiple:false});frame.on('select',function(){var item=frame.state().get('selection').first().toJSON();if(item&&item.url){$('#vina_video_safe_url').val(item.url).trigger('change');}});frame.open();});});
JS;
        wp_add_inline_script( 'jquery', $admin_js );
    }

    public function frontend_assets() {
        if ( ! function_exists( 'is_product' ) || ! is_product() ) { return; }
        $css = '
        .vina-video-safe-button-wrap{display:flex;justify-content:flex-end;width:100%;clear:both;margin:10px 0 16px;position:relative;z-index:2}
        .vina-video-safe-button{display:inline-flex;align-items:center;gap:9px;background:#242424;color:#fff!important;border:0;border-radius:3px;padding:11px 16px;text-decoration:none!important;font-size:14px;line-height:1.2;font-weight:600;cursor:pointer;box-shadow:none;transition:background .2s ease}
        .vina-video-safe-button:hover,.vina-video-safe-button:focus{background:#000;color:#fff!important;outline:2px solid transparent}
        .vina-video-safe-button svg{width:17px;height:17px;fill:#fff;display:block;flex:0 0 auto}
        .vina-video-safe-modal{position:fixed;inset:0;z-index:999999;display:none;align-items:center;justify-content:center;padding:22px;background:rgba(0,0,0,.82);box-sizing:border-box}
        .vina-video-safe-modal.is-open{display:flex}
        .vina-video-safe-dialog{position:relative;width:min(900px,100%);max-height:90vh;background:#000;border-radius:4px;overflow:hidden;box-shadow:0 12px 50px rgba(0,0,0,.45)}
        .vina-video-safe-dialog video{display:block;width:100%;max-height:90vh;height:auto;background:#000}
        .vina-video-safe-close{position:absolute;top:8px;right:8px;z-index:2;width:38px;height:38px;border:0;border-radius:50%;background:rgba(0,0,0,.72);color:#fff;font-size:28px;line-height:1;cursor:pointer;display:flex;align-items:center;justify-content:center}
        body.vina-video-safe-modal-open{overflow:hidden}
        @media(max-width:767px){.vina-video-safe-button-wrap{margin:8px 0 13px}.vina-video-safe-button{padding:10px 13px;font-size:13px}.vina-video-safe-modal{padding:12px}.vina-video-safe-dialog{width:100%}}
        ';
        wp_register_style( 'vina-product-video-safe', false, array(), '1.2.1' );
        wp_enqueue_style( 'vina-product-video-safe' );
        wp_add_inline_style( 'vina-product-video-safe', $css );
        wp_register_script( 'vina-product-video-safe', '', array(), '1.2.1', true );
        wp_enqueue_script( 'vina-product-video-safe' );
        $js = "document.addEventListener('DOMContentLoaded',function(){var modal=document.getElementById('vina-video-safe-modal');if(!modal)return;var video=modal.querySelector('video');var close=modal.querySelector('.vina-video-safe-close');var opener=document.querySelector('.vina-video-safe-button');function shut(){modal.classList.remove('is-open');modal.setAttribute('aria-hidden','true');document.body.classList.remove('vina-video-safe-modal-open');if(video){video.pause();try{video.currentTime=0;}catch(e){}}}function show(e){if(e)e.preventDefault();modal.classList.add('is-open');modal.setAttribute('aria-hidden','false');document.body.classList.add('vina-video-safe-modal-open');if(video){var p=video.play();if(p&&p.catch)p.catch(function(){});}}if(opener)opener.addEventListener('click',show);if(close)close.addEventListener('click',shut);modal.addEventListener('click',function(e){if(e.target===modal)shut();});document.addEventListener('keydown',function(e){if(e.key==='Escape'&&modal.classList.contains('is-open'))shut();});});";
        wp_add_inline_script( 'vina-product-video-safe', $js );
    }

    public function output_button() {
        if ( self::$printed || ! function_exists( 'is_product' ) || ! is_product() ) { return; }
        global $product;
        if ( ! $product instanceof WC_Product ) {
            $product = wc_get_product( get_queried_object_id() );
        }
        if ( ! $product ) { return; }
        $url = get_post_meta( $product->get_id(), self::META_KEY, true );
        // Read a couple of legacy keys so existing product video URLs continue to work.
        if ( ! $url ) { $url = get_post_meta( $product->get_id(), '_vina_video_url', true ); }
        if ( ! $url ) { $url = get_post_meta( $product->get_id(), 'woodmart_product_video', true ); }
        $url = esc_url( $url );
        if ( ! $url ) { return; }
        self::$printed = true;
        ?>
        <div class="vina-video-safe-button-wrap">
            <a class="vina-video-safe-button" href="#vina-video-safe-modal" aria-haspopup="dialog" aria-controls="vina-video-safe-modal">
                <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M8 5.5c0-.8.9-1.3 1.6-.9l10 6.5c.6.4.6 1.3 0 1.7l-10 6.5c-.7.4-1.6-.1-1.6-.9z"/></svg>
                <span>مشاهده ویدئو</span>
            </a>
        </div>
        <div id="vina-video-safe-modal" class="vina-video-safe-modal" role="dialog" aria-modal="true" aria-label="ویدئوی محصول" aria-hidden="true">
            <div class="vina-video-safe-dialog">
                <button type="button" class="vina-video-safe-close" aria-label="بستن ویدئو">&times;</button>
                <video controls playsinline preload="metadata">
                    <source src="<?php echo esc_url( $url ); ?>" type="<?php echo ( preg_match( '/\.webm(?:$|\?)/i', $url ) ? 'video/webm' : ( preg_match( '/\.ogv(?:$|\?)/i', $url ) ? 'video/ogg' : 'video/mp4' ) ); ?>">
                    مرورگر شما از پخش این ویدئو پشتیبانی نمی‌کند.
                </video>
            </div>
        </div>
        <?php
    }
}

add_action( 'plugins_loaded', function() {
    if ( class_exists( 'WooCommerce' ) ) { new Vina_Product_Video_Button_Safe(); }
} );
